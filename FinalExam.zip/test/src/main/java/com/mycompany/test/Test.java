/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.test;
import java.util.*;

/**
 *
 * @author dausingardner
 */
public class Test {

    public static void main(String[] args) {
        String input;
        char inputChar;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter a character: ");
        input = scan.nextLine();
        
        inputChar = input.charAt(0);
        
        //Test if a letter
        
        if (Character.isLetter(inputChar)){
            System.out.println("Character is a letter");
        }
        if (Character.isDigit(inputChar)){
            System.out.println("Character is a digit");
        }
        if (Character.isUpperCase(inputChar)){
            System.out.println("Character is Upper Case");
        }
        if (Character.isLowerCase(inputChar)){
            System.out.println("Character is Lower Case");
        }
            
    }
}
